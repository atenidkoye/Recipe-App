import { Alert } from "react-native";
import Recipe from "./types/recipe";

/**
 * Fetches all public recipes from the server.
 * In case of an error the message is shown to the user via an alert popup.
 * 
 * @param {function} setRecipes Function to set recipes state
 */
export const fetchRecipes = async (setRecipes) => {

  // Fetch public recipes
  const response = await fetch('http://10.0.2.2:4000/api/recipes');

  const body = await response.json();

  // Inform user about error via alert popup
  if (!response.ok) {
    Alert.alert("Error", body.message);
  }

  let recipes = [];

  // Add additional data to the recipe object
  for (let index in body.data) {
    let recipe = new Recipe(body.data[index]);
    await recipe.fetch.categories();
    await recipe.fetch.ingredients();
    recipe.isFavourite = false;
    recipes.push(recipe);
  }

  setRecipes(recipes);
}

/**
 * Fetches recipe data from the server on the user specific endpoint.
 * In case of an error the message is shown to the user via an alert popup.
 * 
 * @param {string} userToken Bearer token of the user used for authorization
 * @param {function} setRecipes Function to set recipes state
 */
export const fetchUserRecipes = async (userToken, setRecipes) => {

  // Fetch recipes created by logged in user
  const response = await fetch('http://10.0.2.2:4000/api/recipes/user/me', {
    method: "GET",
    withCredentials: true,
    credentials: 'include',
    headers: {
      "authorization": `Bearer ${userToken}`
    }
  });

  const body = await response.json();

  // Inform user about error via alert popup
  if (!response.ok) {
    return Alert.alert("Error", body.message);
  }

  let recipes = [];

  // Add additional data to the recipe object
  for (let index in body.data) {
    let recipe = new Recipe(body.data[index]);
    await recipe.fetch.categories();
    await recipe.fetch.ingredients();
    await recipe.fetch.isFavourite(userToken);
    recipes.push(recipe);
  }

  setRecipes(recipes);
}

/**
 * Fetches all avaiable food categories
 * 
 * @returns {Promise<Array>} Array of categories
 */
export const fetchCategories = async () => {
  const response = await fetch('http://10.0.2.2:4000/api/categories');
  const body = await response.json();

  return body.data;
}


/**
 * Update user profile on the server via PUT API call
 * 
 * @param {string} userToken Token used to authrorize user
 * @param {string} name Name to be set for user
 * @param {string} email Email to be set for user
 * @returns {object} Updateduser object
 */
export const updateUserProfile = async (userToken, name, email) => {
  try {
    // PUT API call
    const response = await fetch('http://10.0.2.2:4000/api/users/me', {
      method: 'PUT',
      headers: {
        'authorization': `Bearer ${userToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, email}),
    });

    const data = await response.json();

    // Error
    if (!response.ok) {
      Alert.alert("Error", data.message);
      return null;
    }

    // Updated user data
    return data.user;
  } catch (err) {
    Alert.alert("Error", err);
    return null;
  }
}